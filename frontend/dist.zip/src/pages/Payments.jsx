import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getPayments } from '../store/slices/paymentsSlice';
import DataTable from '../components/common/DataTable';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { CreditCard, CheckCircle, XCircle, Clock } from 'lucide-react';
import { format } from 'date-fns';

const Payments = () => {
  const dispatch = useDispatch();
  const { payments, isLoading } = useSelector((state) => state.payments);

  useEffect(() => {
    dispatch(getPayments());
  }, [dispatch]);

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-600" />;
      default:
        return <Clock className="w-4 h-4 text-yellow-600" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'failed':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'refunded':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300';
      default:
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
    }
  };

  // Calculate stats
  const totalRevenue = payments
    .filter((p) => p.paymentStatus === 'completed')
    .reduce((sum, payment) => sum + payment.amount, 0);
  const completedPayments = payments.filter((p) => p.paymentStatus === 'completed').length;
  const pendingPayments = payments.filter((p) => p.paymentStatus === 'pending').length;
  const failedPayments = payments.filter((p) => p.paymentStatus === 'failed').length;

  const columns = [
    {
      header: 'Order',
      cell: (row) => (
        <span className="font-medium text-gray-900 dark:text-white">
          {row.order?.orderNumber || 'N/A'}
        </span>
      ),
    },
    {
      header: 'Amount',
      cell: (row) => (
        <span className="font-semibold text-gray-900 dark:text-white">
          Rs {row.amount?.toLocaleString()}
        </span>
      ),
    },
    {
      header: 'Method',
      cell: (row) => (
        <span className="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
          {row.paymentMethod}
        </span>
      ),
    },
    {
      header: 'Status',
      cell: (row) => (
        <div className="flex items-center space-x-2">
          {getStatusIcon(row.paymentStatus)}
          <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(row.paymentStatus)}`}>
            {row.paymentStatus}
          </span>
        </div>
      ),
    },
    {
      header: 'Transaction ID',
      cell: (row) => (
        <span className="text-sm text-gray-600 dark:text-gray-400 font-mono">
          {row.transactionId || row.stripePaymentIntentId || 'N/A'}
        </span>
      ),
    },
    {
      header: 'Date',
      cell: (row) => format(new Date(row.createdAt), 'MMM dd, yyyy HH:mm'),
    },
  ];

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <LoadingSpinner size="large" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Payment Management</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-2">View and manage all payment transactions</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">
                Rs {totalRevenue.toLocaleString()}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400">
              <CreditCard className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Completed</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">
                {completedPayments}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400">
              <CheckCircle className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Pending</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">
                {pendingPayments}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-yellow-100 dark:bg-yellow-900/20 text-yellow-600 dark:text-yellow-400">
              <Clock className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Failed</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">
                {failedPayments}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400">
              <XCircle className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>

      <DataTable columns={columns} data={payments} />
    </div>
  );
};

export default Payments;















