import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import menuReducer from './slices/menuSlice';
import orderReducer from './slices/orderSlice';
import userReducer from './slices/userSlice';
import branchReducer from './slices/branchSlice';
import ridersReducer from './slices/ridersSlice';
import paymentsReducer from './slices/paymentsSlice';
import themeReducer from './slices/themeSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    menu: menuReducer,
    orders: orderReducer,
    users: userReducer,
    branches: branchReducer,
    riders: ridersReducer,
    payments: paymentsReducer,
    theme: themeReducer,
  },
});

export default store;
