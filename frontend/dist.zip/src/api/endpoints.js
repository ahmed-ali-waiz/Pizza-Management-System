export const ENDPOINTS = {
  AUTH: {
    LOGIN: '/api/auth/admin/login',
    REGISTER: '/api/auth/register',
    ME: '/api/auth/me',
  },
  USERS: {
    GET_ALL: '/api/users',
    CREATE: '/api/users',
    UPDATE: (id) => `/api/users/${id}`,
    DELETE: (id) => `/api/users/${id}`,
  },
  BRANCHES: {
    GET_ALL: '/api/branches',
    CREATE: '/api/branches',
    UPDATE: (id) => `/api/branches/${id}`,
    DELETE: (id) => `/api/branches/${id}`,
  },
  MENU: {
    GET_ALL: '/api/menu',
    CREATE: '/api/menu',
    UPDATE: (id) => `/api/menu/${id}`,
    DELETE: (id) => `/api/menu/${id}`,
  },
  ORDERS: {
    GET_ALL: '/api/admin/orders',
    CREATE: '/api/admin/orders',
    GET_ONE: (id) => `/api/admin/orders/${id}`,
    UPDATE: (id) => `/api/admin/orders/${id}`,
    UPDATE_STATUS: (id) => `/api/admin/orders/${id}/status`, // Fixed path
    ASSIGN_RIDER: (id) => `/api/admin/orders/${id}/assign-rider`, // Fixed path
    CANCEL: (id) => `/api/admin/orders/${id}/cancel`,
    RATE: (id) => `/api/admin/orders/${id}/rate`,
  },
  RIDERS: {
    GET_ALL: '/api/riders',
    GET_AVAILABLE: '/api/riders/available',
    CREATE: '/api/riders',
    UPDATE: (id) => `/api/riders/${id}`,
    UPDATE_AVAILABILITY: (id) => `/api/riders/${id}/availability`,
    DELETE: (id) => `/api/riders/${id}`,
    GET_ORDERS: (id) => `/api/riders/${id}/orders`,
    GET_HISTORY: (id) => `/api/riders/${id}/history`,
    GET_STATS: (id) => `/api/riders/${id}/stats`,
  },
  PAYMENTS: {
    GET_ALL: '/api/payments',
    CREATE: '/api/payments',
    UPDATE: (id) => `/api/payments/${id}`,
  },
};
